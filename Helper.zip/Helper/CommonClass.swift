//
//  CommonClass.swift
//  G8pass
//
//  Created by iMac on 10/02/23.
//

import Foundation

class CommonClass: NSObject
{
    static var shared = CommonClass()
    //MARK: - UTC To Local
    
    func utcToLocal(dateStr: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        
        if let date = dateFormatter.date(from: dateStr) {
            dateFormatter.timeZone = TimeZone.current
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
            
            return dateFormatter.string(from: date)
        }
        return nil
    }
}


