//
//  AppConstants.swift
//  Jalongi
//
//  Created by Ankit Gabani on 24/06/22.
//

import Foundation
import UIKit

let CURRENT_USER_DATA = "currentUserData"

let CURRENT_MAIN_DATA = "MainData"

let PRIMARY_COLOR = UIColor(red: 18/255, green: 168/255, blue: 156/255, alpha: 1)

let APP_ORANGE_COLOR = UIColor(red: 251/255, green: 170/255, blue: 25/255, alpha: 1)

extension UIColor {
    static var random: UIColor {
        return .init(hue: .random(in: 0...1), saturation: 0.5, brightness: 1, alpha: 1)
    }
}

